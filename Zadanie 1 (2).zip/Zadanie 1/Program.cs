﻿using System;

namespace Zadanie_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(fibonacci(7)); // Podpunkt G
            Console.WriteLine(rownanieKwadratowe(1, -11, 12)); // Podpunkt H
            Console.WriteLine(suma(40)); // Podpunkt I
        }
        static int fibonacci(int number)
        {
            if (number < 3)
                return 1;

            return fibonacci(number - 2) + fibonacci(number - 1);
        }
        static double rownanieKwadratowe(double a, double b, double c)
        {
            if (a == 0)
            {
                return Double.NaN;
            }
            double delta = Math.Pow(b, 2) - (4 * a * c);
            double pierwiastek = Math.Sqrt(delta);
            if (delta > 0)
            {
                double x1 = (-b - pierwiastek) / 2 * a;
                return x1;

            }
            else if (delta == 0)
            {
                double x1 = -b / (2 * a);
                return x1;
            } 
            else
            {
                return Double.NaN;
            }

        }
        static int suma(int number)
        {
            if (number % 7 == 0)
            {
                return number + suma(number - 1);
            } else if (number == 1)
            {
                return number - 1;
            }
            else
            {
                return suma(number - 1);
            }
        }


    
    }
}
